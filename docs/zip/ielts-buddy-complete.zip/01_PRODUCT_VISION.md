# 📚 01_PRODUCT_VISION.md

**"Tại sao chúng ta xây dựng dự án này? Có gì đặc biệt?"**

---

## 🎯 **Product Vision**

**"IELTS Buddy - Lộ trình học tiếng Anh cá nhân hóa bằng AI, cho học sinh 6-15 tuổi"**

---

## 🔍 **Problem Statement**

### **Vấn đề Hiện Tại:**

1. **Làm sao biết con học ở mức nào?**
   - Duolingo: Không có kiểm tra trình độ thực sự
   - ELSA: Đắt (subscription hàng tháng)
   - Teacher riêng: Rất đắt

2. **Làm sao biết con cần học gì tiếp theo?**
   - App hiện tại: Generic learning path
   - Không cá nhân hóa theo trình độ thực tế
   - Bố mẹ không biết tiến độ

3. **Feedback chậm, không tức thì**
   - Speaking/Writing cần người chấm
   - AI scoring chưa phổ biến + đắt tiền

---

## ✨ **Giải Pháp của IELTS Buddy**

```
1. Placement Test nhanh (5 câu)
   ↓
2. AI chấm + định cấp (CEFR: A1-C2)
   ↓
3. Learning Path cá nhân (3 giai đoạn)
   ↓
4. Dashboard cho bố mẹ + con
   ↓
5. Học hằng ngày + Track tiến độ
```

---

## 🎬 **Target Audience**

| Segment | Chi Tiết |
|---------|---------|
| **Chính** | Học sinh lớp 6-9 (12-15 tuổi) muốn ôn IELTS |
| **Secondary** | Học sinh lớp 4-5 muốn nền tảng bền vững |
| **Quyết định mua** | Bố mẹ (decision maker) |
| **Pain point** | Không biết con học ở đâu, cần học gì |

---

## 🏆 **Khác Biệt vs Competitor**

### **vs Duolingo**
| IELTS Buddy | Duolingo |
|------------|----------|
| ✅ Kiểm tra CEFR chính xác | ❌ Không CEFR level |
| ✅ Learning path cá nhân | ❌ Generic path |
| ✅ Focusing IELTS | ❌ General English |
| ✅ Speaking/Writing scoring | ❌ Chỉ listening + reading |
| ❌ Bắt đầu từ 0 | ✅ 500M+ users |

### **vs ELSA**
| IELTS Buddy | ELSA |
|-----------|------|
| ✅ Rẻ (free → freemium) | ❌ $10/tháng |
| ✅ Designed for Vietnam | ❌ Global |
| ✅ Ollama (local) | ❌ Cloud (expensive) |
| ✅ Portfolio showcase | ❌ Competitor's product |
| ❌ Vừa bắt đầu | ✅ Mature product |

### **vs Học với Teacher**
| IELTS Buddy | Teacher |
|------------|---------|
| ✅ Available 24/7 | ❌ Fixed schedule |
| ✅ Instant feedback | ❌ Delayed feedback |
| ✅ Rẻ | ❌ Đắt (500K+/giờ) |
| ❌ Không có "nhân cảm" | ✅ Human touch |
| ✅ Measurable progress | ❌ Subjective |

---

## 🎯 **Key Objectives (3 năm)**

### **Year 1 (MVP)**
```
✓ MVP: Placement test + Learning path + Dashboard
✓ 100 users beta
✓ Get feedback + iterate
✓ Break even or near break-even
```

### **Year 2 (Growth)**
```
✓ Add more features (speaking, writing practice)
✓ 10,000 active users
✓ Monetization: Freemium model
✓ Expansion: Tiếng Nhật, Trung, Pháp
```

### **Year 3 (Scale)**
```
✓ 100,000+ users
✓ B2B: Bán cho schools
✓ AI fine-tuning trên data riêng
✓ Possible acquisition / IPO
```

---

## 💡 **Core Value Propositions**

### **Cho Học Sinh:**
- ✅ Biết trình độ thực tế (CEFR)
- ✅ Có lộ trình rõ ràng (3 giai đoạn)
- ✅ Feedback tức thì từ AI
- ✅ Game-ification (XP, streak, level)

### **Cho Bố Mẹ:**
- ✅ Theo dõi tiến độ con (dashboard)
- ✅ Biết con cần học gì (learning path)
- ✅ Tận dụng thời gian rảnh (ngắn gọn, hiệu quả)
- ✅ Rẻ hơn teacher hoặc app premium

### **Cho Chúng Tôi:**
- ✅ Portfolio project: AI-driven app
- ✅ Reusable framework: Dùng cho app khác
- ✅ Potential revenue: Freemium model
- ✅ Giải quyết bài toán thực tế

---

## 🌟 **Unique Selling Points (USP)**

### **1. Placement Test Tức Thì + Chính Xác**
```
5 câu hỏi → 5 phút → Có CEFR level
(Duolingo: không có; Teacher: 1 tiếng)
```

### **2. Ollama Local (Cost Effective)**
```
Không phải pay API → qwen2.5 local free
(ELSA: $$$; Copilot: $20/month)
```

### **3. Learning Path Cá Nhân**
```
3 giai đoạn dựa trên CEFR của từng HS
(Duolingo: generic; Teacher: flexible nhưng vague)
```

### **4. Speaking/Writing Scoring Tự Động**
```
Ollama chấm bài → Instant feedback
(Teacher: chậm; App khác: không có)
```

### **5. Design Cho Việt Nam**
```
Vietnamese UI, context, examples
(Duolingo: global; bất phù hợp local)
```

---

## 📊 **Success Metrics**

### **Engagement:**
- Daily Active Users (DAU): 100 → 1K → 10K
- Session duration: avg 15 min/day
- Completion rate: % users finish placement test

### **Learning Outcome:**
- CEFR improvement: avg +1 level / 3 months
- Vocabulary retention: 70%+
- User satisfaction: 4.5/5 stars

### **Business:**
- Cost per user: <$1
- Retention rate: 40% MAU
- Revenue (Y2+): Freemium, $5/month

---

## 🎨 **Brand Identity**

**Tone:** Friendly, encouraging, professional
**Color:** Indigo + Purple gradient (modern, trustworthy)
**Mascot:** (Optional) Cute AI character
**Tagline:** "Trở thành thạo tiếng Anh, từng bước nhỏ mỗi ngày"

---

## 🚀 **Go-to-Market Strategy**

### **Phase 1: Bootstrap (MVP)**
- Build for free (side project)
- Release to 10-20 beta users
- Get feedback via survey + usage analytics

### **Phase 2: Organic Growth (Year 1)**
- Launch on ProductHunt
- Facebook groups (parents, students)
- Referral program (10% discount for referrer)

### **Phase 3: Freemium (Year 2)**
- Free: Placement test + basic learning
- Pro ($5/mo): All features + no ads
- Family plan ($10/mo): 3 kids

### **Phase 4: B2B Sales (Year 3)**
- Schools (discounted bulk pricing)
- Tutoring centers
- Online course platforms

---

## ⚠️ **Risks & Mitigation**

| Risk | Probability | Mitigation |
|------|------------|-----------|
| AI scoring not accurate | Medium | Test with real users, iterate |
| Duolingo add IELTS | High | Focus on speed + personalization |
| Local Ollama slow | Low | Use GPU, offload to cloud if needed |
| Data privacy issues | Low | No payment info, GDPR compliance |
| Not monetizable | Medium | Start free, freemium model proven |

---

## 📌 **Lâu Dài: Framework Reusability**

Mục tiêu không chỉ là 1 dự án, mà là 1 **framework** có thể dùng cho:

```
✓ App học tiếng Nhật (Japanese Buddy)
✓ App học lập trình (Coding Buddy)
✓ App quản lý lớp học (Class Buddy)
✓ Bất kỳ learning app nào
```

**Điều này = asset có giá trị cao hơn rất nhiều.**

---

## 🎯 **Decision Criteria**

Khi có conflict:
1. **Giúp học sinh học tốt hơn?** → YES
2. **Có thể build trong 6 sprints?** → YES
3. **Sustainable (không quá complex)?** → YES
4. **Reusable cho app khác?** → BONUS

---

## ✅ **Stakeholders & Approval**

- **Product Owner:** Bạn (Chien)
- **Developer:** AI (Follow framework này)
- **QA:** Bạn (Use 12_TEST_PLAN.md)
- **Approver:** Bạn (Final call on features)

---

**Next:** Đọc `02_PRD.md` để thấy danh sách features chi tiết.

---

**Made with ❤️ for Student Success**
