# 🗄️ 05_DATABASE.md

**Database Design - PostgreSQL Schema for IELTS Buddy**

---

## 📊 **ER Diagram (Entities & Relationships)**

```
┌──────────────┐
│   Learner    │ (1) ──────────(M) ┌─────────────┐
│              │                   │  TestAttempt│
├──────────────┤                   ├─────────────┤
│ id (PK)      │                   │ id (PK)     │
│ email        │                   │ learnerId(FK)
│ password     │                   │ answers (JSON)
│ name         │                   │ scores (JSON)
│ grade        │                   │ cefrResult  │
│ cefrLevel    │                   │ createdAt   │
│ targetIelts  │                   │ updatedAt   │
│ xp           │                   └─────────────┘
│ createdAt    │
│ updatedAt    │
└──────────────┘

Question (independent, used by TestAttempt internally)
```

---

## 📋 **Schema Definition (Prisma)**

```prisma
// This will be in backend/prisma/schema.prisma

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

// ========== MODEL: Learner ==========
// Represents a student/child account

model Learner {
  // Primary Key
  id        String   @id @default(cuid()) @db.VarChar(255)
  
  // Identity
  email     String   @unique @db.VarChar(255)
  password  String   @db.VarChar(255)  // bcrypt hashed!
  name      String   @db.VarChar(100)  // E.g., "Nguyễn Nhật A"
  grade     Int      @db.SmallInt      // 4, 5, 6, 7, 8, 9
  
  // Learning Progress
  cefrLevel String?  @db.VarChar(10)   // A1, A2, B1, B1+, B2, B2+, C1, C2
  targetIelts String? @db.VarChar(50)  // "IELTS 6.0", "IELTS 7.0"
  xp        Int      @default(0)       // Experience points
  
  // Timestamps
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  // Relations
  attempts  TestAttempt[]
  
  // Indexes
  @@index([grade])
  @@index([cefrLevel])
  @@fulltext([name, email])  // For searching
}

// ========== MODEL: Question ==========
// Stores all test questions

model Question {
  // Primary Key
  id       String @id @default(cuid()) @db.VarChar(255)
  
  // Question Content
  skill    String @db.VarChar(50)  // reading|grammar|listening|speaking|writing
  type     String @db.VarChar(50)  // mcq|speaking|writing
  prompt   String @db.Text          // Question text
  sub      String? @db.Text         // Sub-instruction (e.g., "Write 80-100 words")
  
  // Media
  audioUrl String? @db.VarChar(500) // For listening questions
  
  // MCQ Options
  options  Json?                     // ["Option A", "Option B", "Option C", "Option D"]
  answer   Int?                      // Index of correct answer (0-3 for MCQ)
  
  // Metadata
  level    String @db.VarChar(10)   // A1, A2, B1, B1+, B2, B2+, C1, C2
  created AtDateTime @default(now())
  updated At DateTime @updatedAt
  
  // Indexes
  @@index([skill])
  @@index([level])
  @@index([type])
}

// ========== MODEL: TestAttempt ==========
// Stores user test submissions & results

model TestAttempt {
  // Primary Key
  id         String   @id @default(cuid()) @db.VarChar(255)
  
  // Foreign Key
  learnerId  String   @db.VarChar(255)
  learner    Learner  @relation(fields: [learnerId], references: [id], onDelete: Cascade)
  
  // Answers (JSON format)
  answers    Json     // { "q1": "0", "q2": "1", "q4": "My text...", ... }
  
  // Scores (null until computed)
  scores     Json?    // { "reading": 100, "grammar": 70, "listening": 50, "speaking": 65, "writing": 72 }
  cefrResult String?  @db.VarChar(10)  // A1, A2, B1, B1+, B2, B2+, C1, C2
  
  // Feedback
  feedback   String?  @db.Text         // AI feedback (e.g., "Great job on reading!")
  
  // Timestamps
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
  
  // Status (for tracking scoring)
  status     String   @default("pending") @db.VarChar(50) // pending|scored|completed
  
  // Indexes
  @@index([learnerId])
  @@index([createdAt])
  @@index([status])
}
```

---

## 🔑 **Primary Keys & Indexing**

### **Primary Keys (PK)**
```
Learner     → id (cuid: collision-resistant)
Question    → id (cuid)
TestAttempt → id (cuid)
```

### **Indexes (Performance)**
```
Learner
  ├─ grade          (filter by grade level)
  ├─ cefrLevel      (filter by CEFR)
  └─ email          (uniqueness + search)

Question
  ├─ skill          (filter questions by skill)
  ├─ level          (adaptive difficulty)
  └─ type           (MCQ vs open-ended)

TestAttempt
  ├─ learnerId      (find attempts by learner)
  ├─ createdAt      (sort by time)
  └─ status         (find pending scoring)
```

---

## 📝 **Sample Data (Seed)**

### **Learner**
```sql
INSERT INTO "Learner" (id, email, password, name, grade, cefrLevel, targetIelts, xp, createdAt)
VALUES
  ('learner-1', 'ngoc@example.com', '$2b$10$...hashed...', 'Nguyễn Hồng Ngọc', 7, 'A2', 'IELTS 5.5', 100, NOW()),
  ('learner-2', 'duc@example.com', '$2b$10$...hashed...', 'Trần Hữu Đức', 8, 'B1', 'IELTS 6.0', 250, NOW());
```

### **Question**
```sql
INSERT INTO "Question" (id, skill, type, prompt, sub, options, answer, level)
VALUES
  ('q1', 'reading', 'mcq', 'The Amazon rainforest...', NULL, '["Tropical forest","Desert","Mountain","Ocean"]', 0, 'A2'),
  ('q2', 'grammar', 'mcq', 'She ___ every day.', NULL, '["go","goes","going","gone"]', 1, 'A2'),
  ('q5', 'writing', 'writing', 'Write about your hobby', 'Write 80-100 words', NULL, NULL, 'A2');
```

### **TestAttempt**
```sql
INSERT INTO "TestAttempt" (id, learnerId, answers, scores, cefrResult, status)
VALUES
  ('attempt-1', 'learner-1', 
   '{"q1":"0","q2":"1","q3":"2","q4":"I love reading books","q5":"My hobby is..."}',
   '{"reading":100,"grammar":100,"listening":0,"speaking":65,"writing":72}',
   'B1', 'completed');
```

---

## 🔐 **Data Types & Constraints**

| Column | Type | Constraint | Reason |
|--------|------|-----------|--------|
| email | VARCHAR(255) | UNIQUE | No duplicate accounts |
| password | VARCHAR(255) | NOT NULL | Mandatory auth |
| grade | SMALLINT | 4-9 | Small range (saves space) |
| options | JSON | MCQ only | Flexible structure |
| answers | JSON | NOT NULL | Stores any answer type |
| scores | JSON | Nullable | Computed after scoring |
| cefrResult | VARCHAR(10) | Nullable | Computed last |

---

## 🔄 **Relationships**

### **Learner → TestAttempt**
```
Type: 1-to-Many (1 learner can have many attempts)
FK: learnerId in TestAttempt references Learner.id
Cascade: DELETE learner → DELETE all their attempts
```

### **Question (Implicit)**
```
Questions are independent
Not directly linked to TestAttempt
Answers store question IDs as keys in JSON
```

---

## 📊 **Query Examples**

### **Find all attempts by a learner**
```sql
SELECT * FROM "TestAttempt"
WHERE learnerId = 'learner-1'
ORDER BY createdAt DESC;
```

### **Get learner's latest CEFR level**
```sql
SELECT learnerId, cefrResult
FROM "TestAttempt"
WHERE learnerId = 'learner-1' AND cefrResult IS NOT NULL
ORDER BY createdAt DESC
LIMIT 1;
```

### **Get questions for adaptive test (A2 level, reading)**
```sql
SELECT * FROM "Question"
WHERE level = 'A2' AND skill = 'reading'
ORDER BY RANDOM()
LIMIT 1;
```

### **Count completed vs pending attempts**
```sql
SELECT status, COUNT(*) as count
FROM "TestAttempt"
GROUP BY status;
```

---

## 🚀 **Database Migrations (Prisma)**

```bash
# Create database
createdb ielts_buddy

# Push schema to database
npx prisma migrate dev --name init

# Generate Prisma client
npx prisma generate

# Seed database (optional)
npm run seed
```

---

## 🛡️ **Security Considerations**

### **Password Storage**
```
✓ Hash with bcrypt (salt rounds: 10)
✗ NEVER store plaintext passwords
```

### **Data Privacy**
```
✓ No payment data stored
✓ Email + learning data only
✓ Comply with GDPR (right to deletion)
✓ No cookies for PII
```

### **SQL Injection Prevention**
```
✓ Use Prisma ORM (parameterized queries)
✓ Never use string concatenation for queries
```

---

## 📈 **Scalability Notes**

### **For 1,000 users:**
```
✓ Current schema sufficient
✓ Indexes cover common queries
✓ No sharding needed
```

### **For 100,000+ users:**
```
✓ Consider partitioning TestAttempt by date
✓ Archive old attempts to cold storage
✓ Cache CEFR scores in Redis
✓ Denormalize Learner.cefrLevel for fast lookup
```

---

## 📚 **Relationships Diagram (Text)**

```
Learner (1)
    ↓ (M)
    └─→ TestAttempt
           ├─ answers JSON  (references Question.id as keys)
           ├─ scores JSON
           └─ cefrResult

Question (referenced in TestAttempt.answers JSON)
```

---

## ✅ **Sign-Off**

- **Database Architect:** AI
- **Approved by:** Chien
- **Schema Version:** 1.0
- **Date:** [TBD]

---

**Next:** Đọc `06_API.md` để biết endpoints chi tiết.

---

**Made with ❤️ for Data Integrity**
