# 🔌 06_API.md

**Backend API Specification - IELTS Buddy**

---

## 📋 **API Overview**

```
Base URL (Dev):    http://localhost:5000/api
Base URL (Prod):   https://api.ielts-buddy.com/api
Protocol:          REST JSON
Authentication:    JWT Bearer Token
Content-Type:      application/json
Response Format:   JSON
Timeout:           30 seconds
```

---

## 🔐 **Authentication**

### **Headers**

```
Authorization: Bearer [JWT_TOKEN]
Content-Type: application/json
Accept: application/json
```

### **JWT Token**

```
Secret:   Stored in .env (NEVER in code)
Expiry:   7 days
Algorithm: HS256
Claims:   { sub: userId, iat, exp }
```

---

## 🔑 **Auth Endpoints**

### **POST /auth/register**

**Create new user account**

```
Request:
{
  "email": "student@example.com",
  "password": "SecurePass123",
  "name": "Nguyễn Hồng Ngọc"
}

Response (201):
{
  "id": "user-123",
  "email": "student@example.com",
  "name": "Nguyễn Hồng Ngọc",
  "token": "eyJhbGc...",
  "expiresIn": 604800
}

Errors:
  400: { error: "Invalid email format" }
  409: { error: "Email already registered" }
  422: { error: "Password too short (min 8)" }
```

### **POST /auth/login**

**Authenticate and get token**

```
Request:
{
  "email": "student@example.com",
  "password": "SecurePass123"
}

Response (200):
{
  "token": "eyJhbGc...",
  "expiresIn": 604800,
  "user": {
    "id": "user-123",
    "email": "student@example.com",
    "name": "Nguyễn Hồng Ngọc"
  }
}

Errors:
  401: { error: "Invalid email or password" }
  400: { error: "Email and password required" }
```

### **POST /auth/logout**

**Invalidate token (client-side handled)**

```
Request: (POST, no body needed, just send token)

Response (200):
{
  "message": "Logged out successfully"
}
```

---

## 👨‍🎓 **Learner Endpoints**

### **GET /learners**

**Get all learners for current user**

```
Query Params: (none for MVP)

Response (200):
[
  {
    "id": "learner-1",
    "name": "Ngọc",
    "grade": 7,
    "cefrLevel": "A2",
    "targetIelts": "IELTS 5.5",
    "xp": 100,
    "createdAt": "2024-01-15T10:30:00Z"
  },
  {
    "id": "learner-2",
    "name": "Đức",
    "grade": 8,
    "cefrLevel": "B1",
    "targetIelts": "IELTS 6.0",
    "xp": 250,
    "createdAt": "2024-01-20T14:15:00Z"
  }
]

Errors:
  401: { error: "Unauthorized" }
```

### **GET /learners/:id**

**Get specific learner**

```
URL: /learners/learner-1

Response (200):
{
  "id": "learner-1",
  "name": "Ngọc",
  "grade": 7,
  "cefrLevel": "A2",
  "targetIelts": "IELTS 5.5",
  "xp": 100,
  "createdAt": "2024-01-15T10:30:00Z",
  "lastAttempt": {
    "id": "attempt-5",
    "cefrResult": "A2",
    "createdAt": "2024-01-25T09:00:00Z"
  }
}

Errors:
  404: { error: "Learner not found" }
  401: { error: "Unauthorized" }
```

### **POST /learners**

**Create new learner/child profile**

```
Request:
{
  "name": "Lan",
  "grade": 6,
  "targetIelts": "IELTS 5.0"
}

Response (201):
{
  "id": "learner-3",
  "name": "Lan",
  "grade": 6,
  "cefrLevel": null,
  "targetIelts": "IELTS 5.0",
  "xp": 0,
  "createdAt": "2024-01-26T10:00:00Z"
}

Errors:
  400: { error: "Name required" }
  422: { error: "Grade must be 4-9" }
```

### **PUT /learners/:id**

**Update learner profile**

```
URL: /learners/learner-1

Request:
{
  "targetIelts": "IELTS 6.0"
}

Response (200):
{
  "id": "learner-1",
  "name": "Ngọc",
  "grade": 7,
  "targetIelts": "IELTS 6.0",  // ← Updated
  "cefrLevel": "A2",
  "xp": 100,
  "updatedAt": "2024-01-26T11:00:00Z"
}

Errors:
  404: { error: "Learner not found" }
  400: { error: "Invalid target IELTS format" }
```

### **DELETE /learners/:id**

**Delete learner (soft delete recommended)**

```
URL: /learners/learner-3

Response (204): (No content)

Errors:
  404: { error: "Learner not found" }
  403: { error: "Cannot delete" }
```

---

## ❓ **Question Endpoints**

### **GET /questions**

**Get questions for adaptive test**

```
Query Params:
  ?skill=reading          (filter by skill)
  ?level=A2              (filter by level)
  ?limit=1               (number of questions)

Example:
  GET /questions?skill=reading&level=A2&limit=1

Response (200):
[
  {
    "id": "q1",
    "skill": "reading",
    "type": "mcq",
    "prompt": "The Amazon rainforest is the largest tropical forest...",
    "options": ["Tropical forest", "Desert", "Mountain", "Ocean"],
    "level": "A2",
    "audioUrl": null
  }
]

Errors:
  400: { error: "Invalid skill or level" }
```

### **GET /questions/:id** (Optional)

**Get single question details**

```
Response (200):
{
  "id": "q1",
  "skill": "reading",
  "type": "mcq",
  "prompt": "...",
  "options": [...],
  "level": "A2"
}
```

---

## 📝 **Test Attempt Endpoints**

### **POST /attempts**

**Submit test answers**

```
Request:
{
  "learnerId": "learner-1",
  "answers": {
    "q1": "0",              // MCQ: option index
    "q2": "1",
    "q3": "3",
    "q4": "I like reading",    // Speaking: text
    "q5": "My hobby is..."     // Writing: text
  }
}

Response (201):
{
  "id": "attempt-1",
  "learnerId": "learner-1",
  "answers": { ... },
  "scores": {
    "reading": 100,
    "grammar": 100,
    "listening": 0,
    "speaking": null,       // Pending Ollama
    "writing": null
  },
  "cefrResult": null,        // Pending
  "status": "pending",
  "createdAt": "2024-01-26T12:00:00Z"
}

Errors:
  400: { error: "All answers required" }
  404: { error: "Learner not found" }
```

### **POST /attempts/:id/score**

**Trigger scoring (Ollama) and calculate CEFR**

```
URL: /attempts/attempt-1/score

Request: (POST, no body)

Response (200):
{
  "id": "attempt-1",
  "cefr": "B1",
  "scores": {
    "reading": 100,
    "grammar": 100,
    "listening": 0,
    "speaking": 65,
    "writing": 72
  },
  "feedback": "Excellent reading skills! Work on listening.",
  "roadmap": [
    {
      "stage": 1,
      "title": "Foundation",
      "progress": 50,
      "items": ["Vocabulary", "Grammar basics", "Pronunciation"]
    },
    {
      "stage": 2,
      "title": "Intermediate",
      "progress": 0,
      "items": ["Advanced grammar", "Conversations", "Listening"]
    },
    {
      "stage": 3,
      "title": "Exam Prep",
      "progress": 0,
      "items": ["IELTS strategies", "Practice tests", "Fluency"]
    }
  ],
  "resources": [
    { "title": "Cambridge English", "url": "https://..." },
    { "title": "BBC Learning", "url": "https://..." }
  ],
  "updatedAt": "2024-01-26T12:05:00Z"
}

Errors:
  404: { error: "Attempt not found" }
  503: { error: "Ollama service unavailable" }  // Fallback scores returned
```

### **GET /attempts/:id/result**

**Get test result**

```
URL: /attempts/attempt-1/result

Response (200):
{
  "id": "attempt-1",
  "learnerId": "learner-1",
  "cefr": "B1",
  "scores": {
    "reading": 100,
    "grammar": 100,
    "listening": 0,
    "speaking": 65,
    "writing": 72
  },
  "feedback": "Excellent reading skills...",
  "roadmap": [...],
  "resources": [...],
  "createdAt": "2024-01-26T12:00:00Z",
  "completedAt": "2024-01-26T12:05:00Z"
}

Errors:
  404: { error: "Attempt not found" }
```

### **GET /attempts?learnerId=:id**

**Get all attempts for a learner**

```
Query:
  ?learnerId=learner-1
  ?limit=10              (pagination)
  ?offset=0

Response (200):
[
  {
    "id": "attempt-5",
    "cefrResult": "B1",
    "scores": {...},
    "createdAt": "2024-01-26T12:00:00Z"
  },
  {
    "id": "attempt-4",
    "cefrResult": "A2",
    "scores": {...},
    "createdAt": "2024-01-20T10:00:00Z"
  }
]
```

---

## 📊 **Dashboard Endpoint**

### **GET /dashboard/:learnerId**

**Get dashboard data**

```
URL: /dashboard/learner-1

Response (200):
{
  "learner": {
    "id": "learner-1",
    "name": "Ngọc",
    "cefrLevel": "B1",
    "targetIelts": "IELTS 6.0",
    "xp": 1250,
    "streak": 7
  },
  "latestAttempt": {
    "cefrResult": "B1",
    "createdAt": "2024-01-26T12:00:00Z"
  },
  "progress": {
    "stage1": 50,    // percentage
    "stage2": 0,
    "stage3": 0
  },
  "tasks": [
    { "title": "Learn 10 words", "xp": 50, "completed": false },
    { "title": "Practice reading", "xp": 100, "completed": true },
    { "title": "Write essay", "xp": 100, "completed": false }
  ],
  "activity": {
    "mon": 45,  // minutes
    "tue": 60,
    "wed": 30,
    "thu": 0,
    "fri": 90,
    "sat": 0,
    "sun": 0
  }
}
```

---

## ⚠️ **Error Response Format**

```
All errors return JSON:
{
  "error": "Error message",
  "code": "ERROR_CODE",
  "status": 400,
  "timestamp": "2024-01-26T12:00:00Z"
}

Common Status Codes:
  200  OK
  201  Created
  204  No Content
  400  Bad Request (validation error)
  401  Unauthorized (missing/invalid token)
  403  Forbidden (not allowed)
  404  Not Found
  422  Unprocessable Entity (business logic error)
  500  Internal Server Error
  503  Service Unavailable (Ollama down)
```

---

## 🔄 **Rate Limiting**

```
Endpoint:             Limit
POST /auth/login      5 per minute per IP
POST /auth/register   3 per hour per IP
POST /attempts        10 per day per learner
GET /*                1000 per hour per token
```

---

## 📚 **Pagination**

```
Query Parameters:
  ?limit=10   (default: 10, max: 100)
  ?offset=0   (default: 0)

Response includes:
{
  "data": [...],
  "pagination": {
    "total": 50,
    "limit": 10,
    "offset": 0,
    "nextOffset": 10,
    "hasMore": true
  }
}
```

---

## 🧪 **Testing Endpoints**

### **GET /health**

**Health check (no auth required)**

```
Response (200):
{
  "status": "ok",
  "timestamp": "2024-01-26T12:00:00Z",
  "ollama": "connected"  // or "disconnected"
}
```

---

## 📝 **API Version**

```
Current:  v1.0
Endpoint: /api/v1/... (for future versioning)
```

---

**Version:** 1.0
**Last Updated:** [Date]
**Status:** APPROVED
